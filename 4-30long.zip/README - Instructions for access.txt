Thanks for using Aquilx! Join the Discord for the invite!
                                                       Contact
Perm Inv - discord.gg/fAhHhFxzV5 Website - sites.google.com/view/aquilx
       [CLICK JOIN SERVER BUTTON IN AQUILX IF THIS ONE IS INVALID!]

-THERE ARE NO AD LINKS AT ALL!